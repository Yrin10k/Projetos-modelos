<?php include('conexao.php');

if(isset($_POST['email']) or isset($_POST['senha'])){
    if(strlen($_POST['email'])==0){ //strlen() -> conta o número de caracteres
        echo "Preencha seu e-mail";
        
 }elseif (strlen($_POST['senha'])==0) {
    echo "Preencha sua senha";
 }
 else{
    $email = $mysqli->real_escape_string($_POST['email']);// Limpa o conteudo do email
    $senha = $mysqli->real_escape_string($_POST['senha']);// limpa o conteudo da senha

    // verificar o login e senha
    $sql_code = "SELECT * FROM  usarios WHERE email = '$email' AND senha='$senha'";

    $sql_query= $mysqli->query($sql_code) or die('Falha na execução do Codigo SQL'.$mysqli->error);

    $quantidade = $sql_query->num_rows;// Vai retornar quantas linhas a consulta acima retornou / se houver email e senha, será de uma vez

    if ($quantidade == 1) {
         $usuario = $sql_query->fetch_assoc();// pega os dados do usuario no banco, e insere dentro da variavel $usuario



    }else{
        echo "Falha ao logar, E-mail ou Senha Incorretos!"; 
    }
}}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Cadastro</title>
</head>
<body>
    <form action="" method="post">
        <p>
            <label for="email">email</label>
            <input type="email" name="email" id="email">
            
        </p>
        <p>
            
            <label for="senha">senha</label>
            <input type="password" name="senha" id="senha">
        </p>
        <input type="submit" value="login">
</body>
</html>